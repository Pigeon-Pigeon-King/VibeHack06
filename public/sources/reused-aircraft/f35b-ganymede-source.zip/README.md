# F-35B component source

This contains the original mesh/XML/converter archive and the modified runtime component.
The JavaScript factory is reusable with Three.js 0.186.0; the TypeScript adapters integrate
into the host game. No old project directory, online model or external texture is used
at runtime. Full game source is a separate competition delivery.

To reconstruct the original numerical data, extract the inner archive
assets/source/reused-aircraft/vtol-f35b/f35b-source.zip into a separate directory and
follow its included rebuild instructions. Do not overwrite archived originals.
Refer to docs/REUSE_MILITARY_AIR_ASSETS.md for axes, sharing, mechanisms, provenance
and validation boundaries. From the full project, run python3 scripts/package-reused-aircraft.py
after component changes to refresh this bundle.
